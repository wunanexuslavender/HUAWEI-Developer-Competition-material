@echo off
setlocal
chcp 65001 >nul
title 小芳同学——您的专业海报生成助手
pushd "%~dp0" || goto folder_error

where py.exe >nul 2>nul
if errorlevel 1 goto try_python
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>nul
if errorlevel 1 goto try_python
py -3 -X utf8 local_ai.py --open
set "xiaofang_exit=%errorlevel%"
goto finished

:try_python
where python.exe >nul 2>nul
if errorlevel 1 goto python_missing
python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>nul
if errorlevel 1 goto python_missing
python -X utf8 local_ai.py --open
set "xiaofang_exit=%errorlevel%"
goto finished

:python_missing
echo 需要 Python 3.10 或更高版本。请安装 Python，并在安装时勾选 Add Python to PATH。
popd
pause
exit /b 1

:folder_error
echo 无法打开小芳的项目文件夹。
pause
exit /b 1

:finished
popd
if not "%xiaofang_exit%"=="0" pause
exit /b %xiaofang_exit%
