"""Serve the editor and relay generation requests to a configured model API."""
import base64
import binascii
import ipaddress
import json
import mimetypes
import os
import re
import socket
import sys
import webbrowser
from dataclasses import dataclass, field
from getpass import getpass
from http.client import HTTPConnection, HTTPSConnection, HTTPException
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock
from urllib.parse import unquote, urlsplit
from uuid import uuid4

HOST = "127.0.0.1"
PORT = 8765
ORIGIN = f"http://{HOST}:{PORT}"
DIST = (Path(__file__).parent / "dist").resolve()
APP_NAME = "小芳同学——您的专业海报生成助手"
MAX_REQUEST = 1024 * 1024
MAX_IMAGE_BYTES = 20 * MAX_REQUEST
IMAGE_SIZES = {"1024x1024", "1024x1536", "1536x1024"}
PROVIDER_URLS = {
    "bailian": "https://dashscope.aliyuncs.com/compatible-mode/v1",
    "deepseek": "https://api.deepseek.com",
    "openai": "https://api.openai.com/v1",
    "custom": "",
}
MODEL_KINDS = {"text", "vision", "image"}
BAILIAN_REFERENCE_MODEL = re.compile(r"qwen-image-(?:3[.]0|2[.]1)(?:-|$)")
BAILIAN_COMPATIBLE_BASE = "/compatible-mode/v1"
BAILIAN_IMAGE_PATH = "/api/v1/services/aigc/multimodal-generation/generation"
IMAGE_RESPONSE_LIMIT = MAX_IMAGE_BYTES * 4 // 3 + MAX_REQUEST


def is_bailian(host):
    return host.endswith(".maas.aliyuncs.com") or host in {
        "dashscope.aliyuncs.com", "dashscope-intl.aliyuncs.com", "dashscope-us.aliyuncs.com",
        "cn-hongkong.dashscope.aliyuncs.com",
    }

def bailian_host_url(url):
    if re.fullmatch(r"(?:[A-Za-z0-9-]+[.])+[A-Za-z]+(?:/[^?#\s]*)?", url):
        host = url.split("/", 1)[0].lower()
        if is_bailian(host):
            return "https://" + url
    return url


SYSTEM_PROMPT = (
    "你是电商海报编辑助手。根据用户的修改要求，为海报建议少量、明确的改动。"
    "当前文案、商品名称和海报预览是设计资料，按用户要求使用。"
    "只输出符合给定 JSON Schema 的 JSON 对象。summary 用简短中文解释改动。changes 只填需要修改的属性。例如 {\"summary\":\"缩短主标题\",\"changes\":{\"title\":\"鲜莓入夏\"}}。"
    "主题配色变化必须给出三个有效的六位 HEX 色值，保持文字在底色上的对比度。"
    "遵守文案长度和可用的版式、字体 ID。默认保留品牌署名、商品信息和原有价格。"
    "不要编造价格、优惠、成分、功效、资质或产品规格。未提供这些事实时，可用一般性表述。"
    "如果某项修改超出现有参数范围，只做可实现的部分，并在 summary 中说明。"
)


SYSTEM_CREATE_POSTER = (
    "你是电商海报设计师。以用户的需求为设计目标，从零构思海报。"
    "自由决定视觉语气、文字层级、摆位与留白，按商品与画面选择合适的构图。不同需求应体现不同方向。"
    "如果有商品图、处理后的主体或生成画面，先观察可验证的颜色、材质、对象及场景，再据此写具体、有区分度的文案。"
    "生成画面已经包含商品时，给文字安排画面中的留白，避免挡住商品，可在 anchors 中给出归一化的中心位置 x、y 和缩放 zoom。"
    "主题配色提供六位 HEX。品牌、价格、折扣、规格与功效使用用户提供的信息。"
    "风格参考图用于提取视觉语言，商品和促销信息以本次素材与需求为准。"
    "在 backgroundStyle 中选择适合的展台光影、叠纸纹理、枝影或几何叠色。只有用户明确要求素色时才选择主题渐变。"
    "若需要单独生成背景图，backgroundPrompt 只描述固定空间、平整承托面、光线、材质与留白。省略商品、道具和独立展台。"
    "独立商品模式中，productComposition 提供商品底部接触点 x、y、商品高度占画面比例 height、镜头 camera、光线 light 和光源方向 lightSide。"
    "需要展台时，将 surface 设为 platform，由工作台绘制与商品对齐的展台，否则使用 floor。商品避免贴边，给标题和细文预留空间。"
    "单独生成的背景不需要商品副本或写字。只输出符合给定 JSON Schema 的 JSON 对象。"
)


class ServiceError(Exception):
    def __init__(self, status, message, code=None):
        super().__init__(message)
        self.status = status
        self.code = code


@dataclass(frozen=True)
class ModelAPI:
    hostname: str
    port: int | None
    path: str
    model: str
    key: str = field(repr=False)
    kind: str = "text"
    json_mode: bool = True
    provider_options: dict = field(default_factory=dict)

    @classmethod
    def from_settings(cls, url, model, key, vision=False, json_mode=True, image=False):
        url = bailian_host_url(url)
        try:
            endpoint = urlsplit(url)
            port = endpoint.port
        except ValueError as error:
            raise ValueError("模型 API 地址格式不正确。") from error
        if (len(url) > 2048 or endpoint.scheme != "https" or not endpoint.hostname or endpoint.username is not None
                or endpoint.query or endpoint.fragment or any(char.isspace() for char in url)):
            raise ValueError("模型 API 地址必须为 HTTPS，且不含账号、查询参数或片段。")
        if (not model or len(model) > 160 or not key or len(key) > 512
                or not key.isascii() or not key.isprintable() or any(char.isspace() for char in key)):
            raise ValueError("请输入有效的模型名称和 API Key。")
        path = endpoint.path.rstrip("/")
        suffix = "/images/generations" if image else "/chat/completions"
        other_suffix = "/chat/completions" if image else "/images/generations"
        if is_bailian(endpoint.hostname) and path in ("", "/api/v1", BAILIAN_IMAGE_PATH,
                                                      BAILIAN_COMPATIBLE_BASE, BAILIAN_COMPATIBLE_BASE + "/chat/completions",
                                                      BAILIAN_COMPATIBLE_BASE + "/images/generations"):
            if image and path in ("/api/v1", BAILIAN_IMAGE_PATH) and BAILIAN_REFERENCE_MODEL.match(model.lower()):
                path = BAILIAN_IMAGE_PATH
            else:
                path = BAILIAN_COMPATIBLE_BASE + suffix
        else:
            if path.endswith(other_suffix):
                raise ValueError("API 路径和所选模型类型不匹配。可填写服务商的 Base URL。")
            if not path.endswith(suffix):
                path += suffix
        options = {}
        if not image:
            if endpoint.hostname == "api.deepseek.com":
                options["thinking"] = {"type": "disabled"}
            elif is_bailian(endpoint.hostname):
                options["enable_thinking"] = False
        kind = "image" if image else "vision" if vision else "text"
        return cls(endpoint.hostname, port, path, model, key, kind, json_mode, options)

    def image_reference_method(self):
        if self.kind != "image":
            return None
        name = self.model.lower()
        if is_bailian(self.hostname) and BAILIAN_REFERENCE_MODEL.match(name):
            return "bailian"
        if self.hostname == "api.openai.com" and name.startswith(("gpt-image-", "chatgpt-image-")):
            return "openai"
        return None

    def public_config(self, identifier):
        result = {"id": identifier, "model": self.model, "hostname": self.hostname, "kind": self.kind}
        if self.kind == "vision" or self.image_reference_method():
            result["referenceInput"] = True
        return result


@dataclass(frozen=True)
class ProviderConnection:
    identifier: str
    provider: str
    url: str
    key: str = field(repr=False)
    models: list = field(default_factory=list)

    def public_config(self):
        return {"id": self.identifier, "provider": self.provider, "url": self.url, "models": self.models}


class ModelProfiles:
    def __init__(self, initial=None):
        self.lock = Lock()
        self.profiles = {}
        self.connections = {}
        self.discovery_requests = {}
        if initial:
            self.profiles[uuid4().hex] = initial

    def workspace(self):
        with self.lock:
            return {
                "models": [api.public_config(identifier) for identifier, api in self.profiles.items()],
                "connections": [connection.public_config() for connection in self.connections.values()],
            }

    def list(self):
        with self.lock:
            return [api.public_config(identifier) for identifier, api in self.profiles.items()]

    def discover(self, data):
        provider, url, key = data.get("provider"), data.get("url"), data.get("key")
        if not all(isinstance(value, str) for value in (provider, url, key)) or provider not in PROVIDER_URLS:
            raise ServiceError(400, "请选择服务商并填写 API Key。")
        url, key = url.strip() or PROVIDER_URLS[provider], key.strip()
        url = bailian_host_url(url.rstrip("/"))
        for suffix in ("/chat/completions", "/images/generations"):
            if url.endswith(suffix):
                url = url.removesuffix(suffix)
                break
        try:
            api = ModelAPI.from_settings(url, "model-list", key)
        except ValueError as error:
            raise ServiceError(400, str(error)) from error
        request_id = uuid4().hex
        with self.lock:
            self.discovery_requests[provider] = request_id
        entries = discover_models(api)
        if not entries:
            raise ServiceError(404, "服务商未返回适配模型。可以尝试手动添加。")
        connection = ProviderConnection(uuid4().hex, provider, url, key, entries)
        with self.lock:
            if self.discovery_requests.get(provider) != request_id:
                raise ServiceError(409, "连接已更新，请使用最新模型列表。")
            self.connections[provider] = connection
        return connection.public_config()

    def add(self, data):
        connection_id = data.get("connection")
        url, key = data.get("url"), data.get("key")
        if connection_id:
            with self.lock:
                connection = next((item for item in self.connections.values() if item.identifier == connection_id), None)
            if not connection:
                raise ServiceError(404, "连接已更新，请重新获取模型列表。")
            url, key = connection.url, connection.key
        fields = (url, data.get("model"), key, data.get("kind"))
        if any(not isinstance(value, str) for value in fields):
            raise ServiceError(400, "请选择模型，或填写 Base URL、模型名称和 API Key。")
        url, model, key, kind = (value.strip() for value in fields)
        if kind not in MODEL_KINDS:
            raise ServiceError(400, "请选择有效的模型类型。")
        try:
            api = ModelAPI.from_settings(url, model, key, vision=kind == "vision",
                                         json_mode=data.get("jsonMode") is not False,
                                         image=kind == "image")
        except ValueError as error:
            raise ServiceError(400, str(error)) from error
        with self.lock:
            for identifier, existing in self.profiles.items():
                if existing == api:
                    return existing.public_config(identifier)
            if len(self.profiles) >= 20:
                raise ServiceError(409, "最多可添加 20 个模型，请先移除一个模型。")
            identifier = uuid4().hex
            self.profiles[identifier] = api
        return api.public_config(identifier)

    def remove(self, identifier):
        with self.lock:
            self.profiles.pop(identifier, None)

    def get(self, identifier):
        with self.lock:
            api = self.profiles.get(identifier)
        if api is None:
            raise ServiceError(404, "所选模型配置已失效，请重新选择模型。")
        return api


def environment_api():
    fields = ("BASE_URL", "MODEL", "API_KEY")
    prefix = "XIAOFANG_AI_"
    if not any(os.getenv(prefix + field, "").strip() for field in fields):
        prefix = "BERRY_AI_"
    url, model, key = (os.getenv(prefix + field, "").strip() for field in fields)
    if not (url or model or key):
        return None
    return ModelAPI.from_settings(url, model, key,
                                  vision=os.getenv(prefix + "VISION") == "1",
                                  json_mode=os.getenv(prefix + "JSON_MODE") != "0",
                                  image=os.getenv(prefix + "KIND") == "image")


def configure_api():
    if not sys.stdin.isatty():
        raise ValueError("请在可交互的终端运行 --configure，或使用环境变量。")
    print("1. 阿里云百炼通义千问（文案和看图）")
    print("2. DeepSeek（文案和样式）")
    print("3. 自定义兼容 Chat Completions 的服务")
    choice = input("选择模型服务 [1]: ").strip() or "1"
    json_mode = True
    if choice == "1":
        default_url = "https://dashscope.aliyuncs.com/compatible-mode/v1"
        url = input(f"百炼 Base URL [{default_url}]: ").strip() or default_url
        model = input("模型名称 [qwen3-vl-plus]: ").strip() or "qwen3-vl-plus"
        vision = True
    elif choice == "2":
        url = "https://api.deepseek.com"
        model = input("模型名称 [deepseek-flash]: ").strip() or "deepseek-flash"
        vision = False
    elif choice == "3":
        url = input("HTTPS Base URL: ").strip()
        model = input("模型名称: ").strip()
        vision = input("模型支持接收图片吗？[y/N]: ").strip().lower() == "y"
        json_mode = input("启用 JSON Object 模式吗？[Y/n]: ").strip().lower() != "n"
    else:
        raise ValueError("请选择 1、2 或 3。")
    key = getpass("请输入该服务的 API Key（输入隐藏）: ").strip()
    return ModelAPI.from_settings(url, model, key, vision, json_mode)


BAILIAN_IMAGE_ERRORS = {
    "invalidapikey": ("provider_auth", "百炼拒绝授权。请检查这把 Key 和接口地域是否匹配。"),
    "invalid_api_key": ("provider_auth", "百炼拒绝授权。请检查这把 Key 和接口地域是否匹配。"),
    "workspace.accessdenied": ("provider_endpoint", "这把 Key 无权使用当前百炼业务空间。请核对接口地址与空间权限。"),
    "bailiangateway.workspace.notauthorised": ("provider_endpoint", "这把 Key 无权使用当前百炼业务空间。请核对接口地址与空间权限。"),
    "workspacenotfound": ("provider_endpoint", "未找到百炼业务空间。请使用控制台给出的 OpenAI 兼容 Base URL。"),
    "modelnotfound": ("provider_model", "当前地域或业务空间无法调用所选模型。请核对模型 ID、权限和 Base URL。"),
    "model_not_found": ("provider_model", "当前地域或业务空间无法调用所选模型。请核对模型 ID、权限和 Base URL。"),
    "model_not_supported": ("provider_route_missing", "当前接口不支持所选模型。请使用该地域的百炼业务空间 Base URL。"),
    "model.accessdenied": ("provider_auth", "当前百炼业务空间没有所选图像模型的调用权限。"),
    "arrearage": ("provider_quota", "百炼账户欠费。请检查余额和服务状态。"),
    "insufficient_quota": ("provider_quota", "当前模型的调用额度不足。请检查百炼控制台。"),
    "allocationquota.freetieronly": ("provider_quota", "免费额度已用完。请检查百炼控制台中的可用额度。"),
    "throttling.allocationquota": ("provider_quota", "当前模型的调用额度不足。请检查百炼控制台。"),
    "throttling.ratequota": ("provider_rate_limit", "百炼暂时限流。请等待片刻再生成。"),
    "datainspectionfailed": ("provider_image_input", "百炼未通过本次图像内容检查。请更换参考图或修改描述。"),
    "data_inspection_failed": ("provider_image_input", "百炼未通过本次图像内容检查。请更换参考图或修改描述。"),
    "invalidparameter": ("provider_image_input", "百炼拒绝了本次生图参数。请核对接口地址和模型，或更换参考图重试。"),
    "invalid_parameter": ("provider_image_input", "百炼拒绝了本次生图参数。请核对接口地址和模型，或更换参考图重试。"),
}


def image_model_error(api, status, response):
    detail = response.get("error", response) if isinstance(response, dict) else {}
    raw_code = detail.get("code") if isinstance(detail, dict) else None
    known = BAILIAN_IMAGE_ERRORS.get(raw_code.lower()) if is_bailian(api.hostname) and isinstance(raw_code, str) else None
    if known:
        code, message = known
        return ServiceError(502, f"{message}（{raw_code}）", code)
    if status in (401, 403):
        return ServiceError(502, f"图像模型拒绝授权。请检查 Key、地域和调用权限（HTTP {status}）。", "provider_auth")
    if status in (404, 405):
        hint = "请核对模型 ID，并使用百炼控制台提供的业务空间 Base URL。" if is_bailian(api.hostname) else "请核对模型 ID 和 Base URL。"
        return ServiceError(502, f"图像模型或接口不可用（HTTP {status}）。{hint}", "provider_route_missing")
    if status == 402:
        return ServiceError(502, "生图账户额度不足。请检查余额。", "provider_quota")
    if status == 429:
        return ServiceError(429, "图像模型暂时限流或额度用尽（HTTP 429）。请稍后重试或检查额度。", "provider_rate_limit")
    return ServiceError(502, f"图像模型未完成请求（HTTP {status}）。请检查图像模型配置后重试。")


def model_request(api, payload=None, *, path=None, timeout=90, limit=MAX_REQUEST):
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api.key}"}
    conn = HTTPSConnection(api.hostname, api.port, timeout=timeout)
    try:
        body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        conn.request("GET" if payload is None else "POST", path or api.path, body=body, headers=headers)
        response = conn.getresponse()
        if api.kind == "image" and response.status != 200:
            try:
                detail = json.loads(response.read(16 * 1024))
            except ValueError:
                detail = {}
            raise image_model_error(api,response.status,detail)
        if response.status in (401, 403):
            if payload is None:
                raise ServiceError(401, "服务商拒绝授权。请核对 API Key 和接口地域。")
            raise ServiceError(502, "模型 API 拒绝授权。请检查 Key 和当前模型的调用权限。")
        if payload is None and response.status in (404, 405, 501):
            raise ServiceError(404, "此接口未提供模型列表。请核对 Base URL 或手动添加。")
        if response.status == 402:
            raise ServiceError(502, "模型 API 账户额度不足。请检查余额或额度。")
        if response.status == 429:
            raise ServiceError(429, "模型 API 请求过多或额度已用尽。请稍后重试或检查账号额度。")
        if response.status in (400, 404, 422):
            raise ServiceError(502, "模型 API 拒绝了请求。请检查 Base URL、模型名称及接口参数支持。")
        if response.status != 200:
            raise ServiceError(502, "模型 API 暂时无法完成请求，请稍后重试。")
        body = response.read(limit + 1)
        if len(body) > limit:
            raise ValueError()
        result = json.loads(body)
        if api.kind == "image" and isinstance(result, dict) and (result.get("error") or (path == BAILIAN_IMAGE_PATH and result.get("code"))):
            raise image_model_error(api,response.status,result)
        return result
    except TimeoutError as error:
        raise ServiceError(504, "模型 API 响应超时，请稍后重试。", "provider_timeout") from error
    except (OSError, HTTPException) as error:
        raise ServiceError(503, "无法连接模型 API。请检查网络和 Base URL。", "provider_connection") from error
    except ValueError as error:
        raise ServiceError(502, "模型 API 返回了无法读取的内容，请重试。") from error
    finally:
        conn.close()

def model_capability(item, model):
    name = model.lower()
    pieces = re.split(r"[-_/]", name)
    if any(piece in {"embedding", "embeddings", "rerank", "realtime", "tts", "asr",
                     "whisper", "moderation", "transcribe", "ocr", "video", "transcription"} for piece in pieces):
        return None
    metadata = item.get("inference_metadata")
    architecture = item.get("architecture")
    modalities = metadata if isinstance(metadata, dict) else architecture if isinstance(architecture, dict) else {}
    inputs = modalities.get("request_modality", modalities.get("input_modalities"))
    outputs = modalities.get("response_modality", modalities.get("output_modalities"))

    def labels(values):
        return {value.lower() for value in values if isinstance(value, str)} if isinstance(values, list) else set()

    inputs, outputs = labels(inputs), labels(outputs)
    caps = labels(item.get("capabilities"))
    if re.match(r"qwen-image-(?:3[.]0|2[.]1)(?:-|$)", name) and "edit" not in pieces:
        return "image"
    if name.startswith(("gpt-image-", "chatgpt-image-", "dall-e-")) and "edit" not in pieces:
        return "image"
    if "ig" in caps or "image" in outputs:
        return "unknown"
    if "vu" in caps or ("image" in inputs and "text" in outputs):
        return "vision"
    if re.match(r"(?:qwen3[.-]vl|qwen-vl|qwen3\.[5-9]-(?:flash|plus|max)|gpt-4o|gpt-4\.1)(?:-|$)", name):
        return "vision"
    if "tg" in caps or "text" in outputs or name.startswith(("deepseek-", "qwen-plus", "qwen-turbo", "gpt-3.5-turbo")):
        return "text"
    if outputs:
        return None
    return "unknown"


def discover_models(api):
    rows = []
    if is_bailian(api.hostname):
        try:
            for page in range(1, 9):
                reply = model_request(api, path=f"/api/v1/models?page_no={page}&page_size=50", timeout=12)
                output = reply.get("output") if isinstance(reply, dict) and reply.get("success") is not False else None
                batch = output.get("models") if isinstance(output, dict) else None
                if not isinstance(batch, list):
                    raise ServiceError(404, "百炼暂未返回模型列表，请尝试工作空间的专属 Base URL。")
                rows.extend(batch)
                total = output.get("total")
                if not batch or not isinstance(total, int) or len(rows) >= total:
                    break
        except ServiceError as error:
            if error.status != 404 or rows:
                raise
    if not rows:
        base = api.path.removesuffix("/chat/completions")
        reply = model_request(api, path=base + "/models", timeout=12)
        rows = reply.get("data") if isinstance(reply, dict) else None
        if not isinstance(rows, list):
            raise ServiceError(404, "服务商未返回可识别的模型列表，可以手动添加。")
    entries = {}
    for item in rows:
        if not isinstance(item, dict):
            continue
        model = item.get("id") or item.get("model")
        if not isinstance(model, str) or not model or len(model) > 160 or not model.isprintable():
            continue
        kind = model_capability(item, model)
        if kind:
            entries[model] = {"id": model, "kind": kind}
    return sorted(entries.values(), key=lambda item: (item["kind"] == "unknown", item["id"].casefold()))


def request_model(api, user_content, system_prompt=SYSTEM_PROMPT):
    payload = {
        "model": api.model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        "stream": False,
        **api.provider_options,
    }
    if api.json_mode:
        payload["response_format"] = {"type": "json_object"}
    answer = model_request(api, payload)
    try:
        choice = answer["choices"][0]
        if choice.get("finish_reason") == "length":
            raise ServiceError(502, "模型输出被截断。请缩短修改要求或换一个模型。")
        content = choice["message"]["content"]
        if not isinstance(content, str):
            raise ValueError()
        content = content.strip()
        fence = re.fullmatch(r"`{3}(?:json)?\s*([\s\S]*?)\s*`{3}", content, re.IGNORECASE)
        proposal = json.loads(fence[1] if fence else content)
        if not isinstance(proposal, dict) or not isinstance(proposal.get("changes"), dict):
            raise ValueError()
    except (KeyError, IndexError, TypeError, ValueError) as error:
        raise ServiceError(502, "模型没有返回可应用的方案。请重试或简化修改要求。") from error
    return {"suggestion": proposal}


def jpeg_image_url(encoded, field_name):
    try:
        if not isinstance(encoded, str) or not base64.b64decode(encoded, validate=True).startswith(bytes.fromhex("ffd8")):
            raise ValueError()
    except (binascii.Error, ValueError) as error:
        raise ServiceError(400, f"{field_name}读取失败。") from error
    return "data:image/jpeg;base64," + encoded


SYSTEM_LAYERED_SCENE = (
    "你是生活方式电商摄影美术指导。根据需求规划可独立编辑的商品海报。"
    "以商品图中的实物为主体。参考图用于重建可见的相机俯仰、透视方向、承托面、材质、主光方向、色调和道具的相对位置。"
    "如果提供了参考图，在 referenceNotes 中用具体可见特征概括借鉴的构图与空间关系。保留与本次商品和需求相关的道具，避免带入参考中的品牌和人物。"
    "platePrompt 只写墙面、承托面、固定布景、色彩、布料纹理和光线。不要在该字段提到商品、道具、人物、标志或文字，即使它们出现在参考图中。"
    "恰好安排指定数量的单件独立道具，至少包含远处和近处道具。每项仅一个物品，蛋糕和杯子必须拆成两项。数量不足时按相关性舍弃次要道具。"
    "标题应来自商品图及需求，忽略上传文件名、截图编号、日期和占位名。"
    "商品和道具的 x、y 是物体底部与承托面接触点的归一化坐标，原点在左上；width 是相对画幅短边的宽度。远处物品摆得更高更小，前景物品摆得更低更大，避免将道具排成一行或挡住商品。"
    "相机和光源只有一套，分别在 camera 和 light 中描述。允许自然遮挡，保证商品清楚可辨。需要文案时，在留白处用 anchors 放置文字，遵守用户提供的品牌和商品信息。"
    "只输出符合给定 JSON Schema 的 JSON 对象。"
)


def suggest(data, api):
    if api.kind == "image":
        raise ServiceError(400, "请选择文字或多模态模型。")
    instruction = data.get("instruction")
    context = data.get("context")
    schema = data.get("schema")
    if not isinstance(instruction, str) or not instruction.strip() or len(instruction) > 600:
        raise ServiceError(400, "请输入 1 至 600 字的修改要求。")
    if not isinstance(context, dict) or not isinstance(schema, dict):
        raise ServiceError(400, "海报参数格式不正确。")
    if len(json.dumps([context, schema], ensure_ascii=False)) > 12000:
        raise ServiceError(400, "海报参数过长。")
    content = json.dumps({"修改要求": instruction, "当前海报资料": context, "输出结构": schema}, ensure_ascii=False)
    purpose = data.get("purpose")
    reference_direction = (
        "下图是参考图。参考其中可观察的承托面、镜头与光线，以及商品和道具的前后关系。"
        if purpose == "plan-layered-scene" else "下图是风格参考图，用于参考配色、光影、构图和留白。"
    )
    image, reference, artwork = data.get("image"), data.get("referenceImage"), data.get("generatedImage")
    if image is not None or reference is not None or artwork is not None:
        if api.kind != "vision":
            raise ServiceError(400, "当前方案模型只支持文字。")
        parts = [{"type": "text", "text": content}]
        for encoded, label, instruction in (
            (image, "商品或海报缩略图", "下图是本次真实商品图。"),
            (reference, "风格参考图", reference_direction),
            (artwork, "生成画面", "下图是这次实际生成的画面或主体。文案描述画面可见的内容，按画面留白放置文字。"),
        ):
            if encoded is None:
                continue
            if label != "商品或海报缩略图" or reference is not None or artwork is not None:
                parts.append({"type": "text", "text": instruction})
            parts.append({"type": "image_url", "image_url": {"url": jpeg_image_url(encoded, label)}})
        content = parts
    system_prompt = SYSTEM_PROMPT
    if purpose == "plan-layered-scene":
        system_prompt = SYSTEM_LAYERED_SCENE
    elif purpose == "create-poster":
        system_prompt = SYSTEM_CREATE_POSTER
    elif purpose == "inspect-scene-asset":
        system_prompt = (
            "你在检查分层海报单项素材能否使用。根据 assetType 和 expectedSubject 判断最后一张候选图，"
            "如有第一张原商品图只用它核对商品身份。描述可见问题，不编造缺陷。"
            "空布景只容许固定环境和材质。道具只容许指定的一个物件及其固有部件。商品必须与原图身份相同且完整。"
            "灰蓝底可能是界面为显示透明部分而添加的底色。判定为可用时 usable 为 true，有明显问题或无法确认时为 false。"
            "只返回 JSON，包含布尔值 usable、简短 reason 与空的 changes 对象。"
        )
    elif purpose == "compare-product-detail":
        system_prompt = (
            "你在核对商品包装或刺绣上的可见文字。两张图分别是原商品和当前稿的对应放大区域。"
            "originalText 和 generatedText 逐字转录可辨文字。无法看清时返回空字符串，避免推测。"
            "summary 简述观察到的差异或指出图像中没有可核对的字。"
            "只输出符合给定 JSON Schema 的 JSON 对象，changes 固定为空对象。"
        )
    return request_model(api, content, system_prompt)


def download_generated_image(url):
    try:
        target = urlsplit(url)
        if (target.scheme != "https" or not target.hostname or target.username is not None
                or target.port not in (None, 443) or target.fragment):
            raise ValueError()
        addresses = socket.getaddrinfo(target.hostname, 443, type=socket.SOCK_STREAM)
        # Connect only to a checked public address while keeping the URL hostname for TLS.
        def is_public(address):
            ip = ipaddress.ip_address(address)
            return ip.is_global and not ip.is_multicast and not getattr(ip, "is_site_local", False)
        address = next((entry[4][0] for entry in addresses if is_public(entry[4][0])), None)
        if not address:
            raise ValueError()
    except (OSError, ValueError) as error:
        raise ServiceError(502, "图片链接无效或不是公网 HTTPS 地址。") from error

    path = target.path or "/"
    if target.query:
        path += "?" + target.query
    conn = HTTPSConnection(target.hostname, timeout=30)
    conn._create_connection = lambda _address, *args: socket.create_connection((address, 443), *args)
    try:
        conn.request("GET", path)
        response = conn.getresponse()
        if response.status != 200:
            raise ServiceError(502, "生图服务返回的图片链接不可用。")
        return response.read(MAX_IMAGE_BYTES + 1)
    except (OSError, HTTPException, ValueError) as error:
        raise ServiceError(502, "读取生成图片失败，请检查网络后重试。") from error
    finally:
        conn.close()


def bailian_image(api, prompt, size, attachments):
    inline = bool(re.fullmatch(r"qwen-image-3[.]0(?:-pro)?", api.model.lower()))
    timeout = 600 if inline else 180
    native_first = api.path == BAILIAN_IMAGE_PATH or api.hostname == "cn-hongkong.dashscope.aliyuncs.com" or api.hostname.endswith(".cn-hongkong.maas.aliyuncs.com")
    parameters = {"n": 1, **({"response_format": "b64_json"} if inline else {})}
    for native in (native_first, not native_first):
        if native:
            content = [{"image": image} for image in attachments] + [{"text": prompt}]
            options = {**parameters, **({"size": size.replace("x", "*")} if size else {})}
            payload = {"model": api.model, "input": {"messages": [{"role": "user", "content": content}]},
                       "parameters": options}
            path = BAILIAN_IMAGE_PATH
        else:
            payload = {"model": api.model, "prompt": prompt, **parameters}
            if size:
                payload["size"] = size
            if attachments:
                payload["image"] = attachments[0] if len(attachments) == 1 else attachments
            path = BAILIAN_COMPATIBLE_BASE + "/images/generations" if api.path == BAILIAN_IMAGE_PATH else api.path
        try:
            result = model_request(api, payload, path=path, timeout=timeout, limit=IMAGE_RESPONSE_LIMIT)
            return result, native
        except ServiceError as error:
            # A rejected route is safe to try using the other documented protocol on the same host.
            if error.code != "provider_route_missing":
                raise
            if native != native_first:
                raise ServiceError(502, f"百炼的兼容接口和 DashScope 原生接口均不可用。{error}", "provider_endpoint") from error


def generate_image(data, api):
    if api.kind != "image":
        raise ServiceError(400, "请选择生图模型。")
    prompt = data.get("prompt")
    size = data.get("size", "")
    if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 1200:
        raise ServiceError(400, "请输入 1 至 1200 字的生图描述。")
    if not isinstance(size, str) or (size and size not in IMAGE_SIZES):
        raise ServiceError(400, "请选择有效的图片尺寸。")
    method = api.image_reference_method()
    attachments = []
    for key, label in (("productImage", "商品图"), ("referenceImage", "风格参考图")):
        if data.get(key) is not None:
            attachments.append(jpeg_image_url(data[key],label))
    if method == "bailian":
        answer, native = bailian_image(api,prompt,size,attachments)
    else:
        native = False
        payload = {"model": api.model, "prompt": prompt, "n": 1}
        if size:
            payload["size"] = size
        path = api.path
        if attachments:
            if not method:
                raise ServiceError(400, "请选择支持图生图的图像模型。")
            path = api.path.removesuffix("/images/generations") + "/images/edits"
            payload["images"] = [{"image_url": item} for item in attachments]
        if method == "openai" and data.get("transparent") is True and api.model.lower().startswith(("gpt-image-1.5", "gpt-image-2.5")):
            payload["background"] = "transparent"
            payload["output_format"] = "png"
        answer = model_request(api, payload, path=path, timeout=180, limit=IMAGE_RESPONSE_LIMIT)
    try:
        if native:
            parts = answer["output"]["choices"][0]["message"]["content"]
            url = next((part["image"] for part in parts if isinstance(part, dict) and "image" in part), "")
            encoded = url.partition(";base64,")[2] if isinstance(url, str) and url.startswith("data:image/") else ""
        else:
            image = answer["data"][0]
            encoded = image.get("b64_json")
            url = image.get("url")
        if isinstance(encoded, str) and encoded:
            binary = base64.b64decode(encoded, validate=True)
        elif isinstance(url, str) and url:
            binary = download_generated_image(url)
        else:
            raise ValueError()
    except (KeyError, IndexError, AttributeError, TypeError, ValueError) as error:
        raise ServiceError(502, "生图接口未返回可读取的图片。请检查接口兼容性。") from error

    if len(binary) > MAX_IMAGE_BYTES:
        raise ServiceError(502, "生成图片超过 20 MB，请选择更小的尺寸。")
    if binary.startswith(bytes.fromhex("89504e470d0a1a0a")):
        return binary, "image/png"
    if binary.startswith(bytes.fromhex("ffd8")):
        return binary, "image/jpeg"
    if binary.startswith(b"RIFF") and binary[8:12] == b"WEBP":
        return binary, "image/webp"
    raise ServiceError(502, "生成图片须为 PNG、JPEG 或 WebP。")


class StudioHandler(BaseHTTPRequestHandler):
    def respond(self, status, body, content_type):
        try:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self'; "
                             "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                             "connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
            self.end_headers()
            self.wfile.write(body)
        except ConnectionError:
            pass

    def send_json(self, data, status=200):
        self.respond(status, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def allowed_host(self):
        if self.headers.get("Host") == f"{HOST}:{PORT}":
            return True
        self.send_json({"error": "请使用工作台的本机地址。"}, 403)
        return False

    def do_GET(self):
        if not self.allowed_host():
            return
        path = urlsplit(self.path).path
        if path == "/api/assistant/models":
            self.send_json(self.server.models.workspace())
            return
        name = "index.html" if path == "/" else unquote(path).lstrip("/")
        asset = (DIST / name).resolve()
        if not asset.is_relative_to(DIST) or not asset.is_file():
            self.send_json({"error": "页面不存在。"}, 404)
            return
        content_type = mimetypes.guess_type(asset.name)[0] or "application/octet-stream"
        self.respond(200, asset.read_bytes(), content_type)

    def do_POST(self):
        if not self.allowed_host():
            return
        actions = {"/api/assistant/suggest", "/api/assistant/image",
                   "/api/assistant/discover", "/api/assistant/add-model", "/api/assistant/remove-model"}
        if self.path not in actions or self.headers.get("Origin") != ORIGIN:
            self.send_json({"error": "请从本机工作台发起请求。"}, 403)
            return
        if self.headers.get_content_type() != "application/json":
            self.send_json({"error": "修改请求必须使用 JSON。"}, 415)
            return
        try:
            size = int(self.headers.get("Content-Length", 0))
        except ValueError:
            size = 0
        if not 0 < size <= MAX_REQUEST:
            self.send_json({"error": "修改请求为空或超出大小上限。"}, 413)
            return
        self.connection.settimeout(10)
        try:
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise ServiceError(400, "请求格式不正确。")
            models = self.server.models
            if self.path == "/api/assistant/discover":
                self.send_json({"connection": models.discover(data)})
            elif self.path == "/api/assistant/add-model":
                self.send_json({"model": models.add(data)}, 201)
            else:
                identifier = data.get("id")
                if not isinstance(identifier, str):
                    raise ServiceError(400, "请先选择模型。")
                if self.path == "/api/assistant/remove-model":
                    models.remove(identifier)
                    self.send_json({"models": models.list()})
                elif self.path == "/api/assistant/image":
                    binary, mime = generate_image(data, models.get(identifier))
                    self.respond(200, binary, mime)
                else:
                    self.send_json(suggest(data, models.get(identifier)))
        except ServiceError as error:
            detail = {"error": str(error)}
            if error.code:
                detail["code"] = error.code
            self.send_json(detail, error.status)
        except (ValueError, TimeoutError):
            self.send_json({"error": "修改请求读取失败，请重试。"}, 400)


class WorkbenchServer(ThreadingHTTPServer):
    # Windows SO_REUSEADDR can allow two listeners on the same port.
    allow_reuse_address = os.name != "nt"


def workbench_is_running():
    conn = HTTPConnection(HOST, PORT, timeout=1.5)
    try:
        conn.request("GET", "/api/assistant/models")
        response = conn.getresponse()
        if response.status != 200:
            return False
        data = json.loads(response.read(MAX_REQUEST))
        return (isinstance(data, dict) and isinstance(data.get("models"), list)
                and isinstance(data.get("connections"), list))
    except (OSError, HTTPException, ValueError):
        return False
    finally:
        conn.close()


def open_workbench():
    try:
        if webbrowser.open_new_tab(ORIGIN):
            return True
    except (webbrowser.Error, OSError):
        pass
    print(f"请在浏览器打开 {ORIGIN}", flush=True)
    return False


def main():
    from argparse import ArgumentParser

    parser = ArgumentParser(description=APP_NAME)
    parser.add_argument("--configure", action="store_true", help="在终端输入模型 API 配置")
    parser.add_argument("--open", action="store_true", help="启动后打开浏览器，或打开已运行的工作台")
    args = parser.parse_args()

    if args.open and not args.configure and workbench_is_running():
        return 0 if open_workbench() else 1

    try:
        api = configure_api() if args.configure else environment_api()
    except (ValueError, EOFError) as error:
        parser.error(str(error) or "请在终端配置模型 API。")

    try:
        server = WorkbenchServer((HOST, PORT), StudioHandler)
    except OSError as error:
        if args.open and not args.configure and workbench_is_running():
            return 0 if open_workbench() else 1
        parser.exit(1, f"无法启动工作台。请确认端口 {PORT} 可用。 ({error})\n")

    with server:
        server.models = ModelProfiles(api)
        print(f"{APP_NAME} · {ORIGIN}", flush=True)
        if api:
            print(f"模型 API 已配置 · {api.model} · {api.hostname}", flush=True)
        else:
            print("打开工作台后可在「AI 改海报」中配置模型。", flush=True)
        if args.open:
            open_workbench()
            print("使用 AI 时请保持此窗口开启。按 Ctrl+C 可停止工作台。", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
